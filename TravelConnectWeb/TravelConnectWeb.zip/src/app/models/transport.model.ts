export class Transport {
    flightCarrier!: string;
    flightNumber!: string;
}